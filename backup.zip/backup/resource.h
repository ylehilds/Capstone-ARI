//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFPlayer.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDB_SLIDER                      103
#define IDB_MUTE                        111
#define IDB_PLAY                        112
#define IDD_OPENURL                     113
#define IDD_OPENFILE_EXT                114
#define IDC_VIDEO                       1001
#define IDC_VIDEO_ZOOM                  1002
#define IDC_SEEKBAR                     1003
#define IDC_VIDEO_BRIGHTNESS            1004
#define IDC_VIDEO_BRIGHTNESS2           1005
#define IDC_VIDEO_CONTRAST              1005
#define IDC_MUTE                        1006
#define IDC_PLAY                        1007
#define IDC_REWIND                      1008
#define IDC_FASTFORWARD                 1009
#define IDC_STATUS_BAR                  1010
#define IDC_UP                          1010
#define IDC_EDIT_URL                    1011
#define IDC_DOWN                        1011
#define IDC_EVR_PRESENTER               1012
#define IDC_RIGHT                       1012
#define IDC_CLSID_PRESENTER             1013
#define IDC_UP2                         1013
#define IDC_LEFT                        1013
#define IDC_EVR_MIXER                   1014
#define IDC_CLSID_MIXER                 1015
#define ID_FILE_OPENFILE                40001
#define ID_FILE_EXIT                    40002
#define ID_FILE_OPENURL                 40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
