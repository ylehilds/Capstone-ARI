//------------------------------------------------------------------------------
//
// File: MainDialog.h
// Implements the main dialog.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
//------------------------------------------------------------------------------

#pragma once

class MainDialog : public CBaseDialog
{
public:
    MainDialog();
    ~MainDialog();

    // Message handlers

    // WM_INITDIALOG
	HRESULT OnInitDialog(); 
    // WM_COMMAND
    INT_PTR OnCommand(HWND hControl, WORD idControl, WORD msg);
    // WM_NOTIFY
    LRESULT OnNotify(NMHDR *pHdr);
    // Other messages
    INT_PTR OnReceiveMsg(UINT msg, WPARAM wParam, LPARAM lParam);

private:

	HRESULT InitializeControls();
    void    UpdateUI();
    void    UpdateSeekBar();
    void    StopTimer();
    HRESULT InitStatusBar();
    void    SetStatusText(const WCHAR *szStatus)
    {
        m_status.SetText(0, szStatus);
    }
    void    SetStatusTime(const MFTIME& time);

    // Commands
    BOOL    OnCancel();
	void	OnFileOpen();
    void    OnOpenURL();
    void    OnScroll(WORD request, WORD position, HWND hControl);
    void    OnSeekbarNotify(const NMSLIDER_INFO *pInfo);
	void    OnVolumeNotify(const NMSLIDER_INFO *pInfo);
    void    OnTimer();
    void    OnMute();
    void    OnPlayOrPause();
	void	MoveLeft();
	void	MoveRight();
	void	MoveUp();
	void	MoveDown();

    // Player state notifications
    void    OnPlayerNotify(PlayerState state);
    void    OnPlayerReady();

    // Player events
    void    OnPlayerEvent(PlayerEvent playerEvent, LPARAM lParam);
    void    OnVolumeChanged();


private:
    ISamplePlayer   *m_pPlayer;
    IPlayerVideo    *m_pVideo;
    IPlayerAudio    *m_pAudio;
    IPlayerSeeking  *m_pSeeking;

    // UI Controls
    Slider          m_seekbar;
    Slider          m_volume;
    Trackbar        m_Zoom;
	Trackbar		m_Brightness;
	Trackbar		m_Contrast;
    ThemedButton    m_mute;
    ThemedButton    m_play;
    Button          m_btnFastFwd;
    Button          m_btnRewind;
	Button			m_up;
	Button			m_down;
	Button			m_left;
	Button			m_right;
    StatusBar       m_status;

	UINT_PTR	    m_timerID; 
};


